-- POS Application Database Backup
-- Date: 2025-04-27T14:20:24.816770
-- Database: neondb

-- Table: categories
DROP TABLE IF EXISTS categories CASCADE;
CREATE TABLE categories (
category_id character varying NOT NULL,
name character varying NOT NULL,
description text NULL,
parent_id character varying NULL,
created_at timestamp without time zone NOT NULL,
updated_at timestamp without time zone NOT NULL
);

-- Data for table: categories
INSERT INTO categories (category_id, name, description, parent_id, created_at, updated_at) VALUES ('3c074193-59d2-4d8c-a186-f106bf6b449f', 'Electronics', 'Electronic devices and accessories', NULL, '2025-04-27T11:04:24.323111', '2025-04-27T11:04:24.323111');
INSERT INTO categories (category_id, name, description, parent_id, created_at, updated_at) VALUES ('0d542cfe-6ac7-4828-92e7-23d5951c3cfa', 'Clothing', 'Apparel and fashion items', NULL, '2025-04-27T11:04:24.400134', '2025-04-27T11:04:24.400134');
INSERT INTO categories (category_id, name, description, parent_id, created_at, updated_at) VALUES ('8c38471a-0db3-44e0-9d22-286fe9736781', 'Groceries', 'Food and household items', NULL, '2025-04-27T11:04:24.462943', '2025-04-27T11:04:24.462943');
INSERT INTO categories (category_id, name, description, parent_id, created_at, updated_at) VALUES ('2f6862d8-281c-4e77-8807-650faf26a84c', 'Stationery', 'Office and school supplies', NULL, '2025-04-27T11:04:24.525139', '2025-04-27T11:04:24.525139');

-- Table: users
DROP TABLE IF EXISTS users CASCADE;
CREATE TABLE users (
user_id character varying NOT NULL,
username character varying NOT NULL,
password_hash character varying NOT NULL,
full_name character varying NOT NULL,
role character varying NOT NULL,
email character varying NULL,
phone character varying NULL,
active boolean NOT NULL DEFAULT true,
created_at timestamp without time zone NOT NULL,
updated_at timestamp without time zone NOT NULL,
last_login timestamp without time zone NULL
);

-- Data for table: users
INSERT INTO users (user_id, username, password_hash, full_name, role, email, phone, active, created_at, updated_at, last_login) VALUES ('4944fa45-1c82-45b7-b40d-1e8e0245039b', 'admin', '$2b$12$DJiNgPcSud.SUB51fJFyme2J/2cbECA3U0ZkO/zWJuulkh/zQeBmu', 'System Administrator', 'ADMIN', 'admin@example.com', NULL, True, '2025-04-27T11:03:10.981871', '2025-04-27T11:03:10.981871', NULL);

-- Table: products
DROP TABLE IF EXISTS products CASCADE;
CREATE TABLE products (
product_id character varying NOT NULL,
name character varying NOT NULL,
sku character varying NOT NULL,
barcode character varying NULL,
category_id character varying NOT NULL,
description text NULL,
purchase_price numeric NOT NULL,
selling_price numeric NOT NULL,
tax_rate numeric NOT NULL DEFAULT 0,
low_stock_threshold integer NOT NULL DEFAULT 10,
is_active boolean NOT NULL DEFAULT true,
created_at timestamp without time zone NOT NULL,
updated_at timestamp without time zone NOT NULL
);

-- Data for table: products
INSERT INTO products (product_id, name, sku, barcode, category_id, description, purchase_price, selling_price, tax_rate, low_stock_threshold, is_active, created_at, updated_at) VALUES ('f6e181e1-eaab-412f-8341-9457bb2cbc98', 'Smartphone', 'PHONE001', '1234567890123', '3c074193-59d2-4d8c-a186-f106bf6b449f', 'Latest smartphone model', '300.00', '499.99', '0.00', 10, True, '2025-04-27T11:04:24.676750', '2025-04-27T11:04:24.676750');
INSERT INTO products (product_id, name, sku, barcode, category_id, description, purchase_price, selling_price, tax_rate, low_stock_threshold, is_active, created_at, updated_at) VALUES ('492137c0-7ca5-4021-8192-0a4312b01322', 'Laptop', 'LAPT001', '1234567890124', '3c074193-59d2-4d8c-a186-f106bf6b449f', 'High performance laptop', '600.00', '999.99', '0.00', 10, True, '2025-04-27T11:04:24.785967', '2025-04-27T11:04:24.785967');
INSERT INTO products (product_id, name, sku, barcode, category_id, description, purchase_price, selling_price, tax_rate, low_stock_threshold, is_active, created_at, updated_at) VALUES ('090dd16f-6e37-4334-ae76-b6c35deb963f', 'T-Shirt', 'TSHIRT001', '2234567890123', '0d542cfe-6ac7-4828-92e7-23d5951c3cfa', 'Cotton T-shirt', '5.00', '15.99', '0.00', 10, True, '2025-04-27T11:04:24.894070', '2025-04-27T11:04:24.894070');
INSERT INTO products (product_id, name, sku, barcode, category_id, description, purchase_price, selling_price, tax_rate, low_stock_threshold, is_active, created_at, updated_at) VALUES ('6af25dab-60cd-4694-ba57-e5a41470c608', 'Jeans', 'JEANS001', '2234567890124', '0d542cfe-6ac7-4828-92e7-23d5951c3cfa', 'Denim jeans', '20.00', '39.99', '0.00', 10, True, '2025-04-27T11:04:25.010431', '2025-04-27T11:04:25.010431');
INSERT INTO products (product_id, name, sku, barcode, category_id, description, purchase_price, selling_price, tax_rate, low_stock_threshold, is_active, created_at, updated_at) VALUES ('214a5c5c-d345-4a3f-818e-e674d59f773c', 'Milk', 'MILK001', '3234567890123', '8c38471a-0db3-44e0-9d22-286fe9736781', 'Fresh milk 1L', '0.80', '1.99', '0.00', 10, True, '2025-04-27T11:04:25.114792', '2025-04-27T11:04:25.114792');
INSERT INTO products (product_id, name, sku, barcode, category_id, description, purchase_price, selling_price, tax_rate, low_stock_threshold, is_active, created_at, updated_at) VALUES ('45f6ecac-a488-49e3-ac2a-9378cf7235ec', 'Bread', 'BREAD001', '3234567890124', '8c38471a-0db3-44e0-9d22-286fe9736781', 'Fresh bread loaf', '1.00', '2.49', '0.00', 10, True, '2025-04-27T11:04:25.218704', '2025-04-27T11:04:25.218704');
INSERT INTO products (product_id, name, sku, barcode, category_id, description, purchase_price, selling_price, tax_rate, low_stock_threshold, is_active, created_at, updated_at) VALUES ('5cb03b88-c3e6-44e8-9741-7e5fb7ada20e', 'Notebook', 'NOTE001', '4234567890123', '2f6862d8-281c-4e77-8807-650faf26a84c', '100-page notebook', '1.50', '3.99', '0.00', 10, True, '2025-04-27T11:04:25.326118', '2025-04-27T11:04:25.326118');
INSERT INTO products (product_id, name, sku, barcode, category_id, description, purchase_price, selling_price, tax_rate, low_stock_threshold, is_active, created_at, updated_at) VALUES ('e09da891-24dc-401d-977e-c15087a6697b', 'Pen Set', 'PEN001', '4234567890124', '2f6862d8-281c-4e77-8807-650faf26a84c', 'Set of 5 ballpoint pens', '2.00', '4.99', '0.00', 10, True, '2025-04-27T11:04:25.437488', '2025-04-27T11:04:25.437488');

-- Table: stock
DROP TABLE IF EXISTS stock CASCADE;
CREATE TABLE stock (
stock_id character varying NOT NULL,
product_id character varying NOT NULL,
quantity integer NOT NULL DEFAULT 0,
created_at timestamp without time zone NOT NULL,
updated_at timestamp without time zone NOT NULL
);

-- Data for table: stock
INSERT INTO stock (stock_id, product_id, quantity, created_at, updated_at) VALUES ('577c46cb-fdfe-4f34-bd5d-a33d0bcc6f6e', 'f6e181e1-eaab-412f-8341-9457bb2cbc98', 98, '2025-04-27T11:06:08.319548', '2025-04-27T11:06:08.319548');
INSERT INTO stock (stock_id, product_id, quantity, created_at, updated_at) VALUES ('ef708965-f02e-4117-8558-1da68be2c917', '492137c0-7ca5-4021-8192-0a4312b01322', 30, '2025-04-27T11:06:08.458099', '2025-04-27T11:06:08.458099');
INSERT INTO stock (stock_id, product_id, quantity, created_at, updated_at) VALUES ('006702e2-76a1-49cf-9cac-b895498a5616', '090dd16f-6e37-4334-ae76-b6c35deb963f', 23, '2025-04-27T11:06:08.585309', '2025-04-27T11:06:08.585309');
INSERT INTO stock (stock_id, product_id, quantity, created_at, updated_at) VALUES ('29f3c28e-a1fb-42b7-b00b-f637f6a6ce86', '6af25dab-60cd-4694-ba57-e5a41470c608', 24, '2025-04-27T11:06:08.715896', '2025-04-27T11:06:08.715896');
INSERT INTO stock (stock_id, product_id, quantity, created_at, updated_at) VALUES ('8e8a4699-6c7a-444c-b62f-3442c80c6bd6', '214a5c5c-d345-4a3f-818e-e674d59f773c', 85, '2025-04-27T11:06:08.844589', '2025-04-27T11:06:08.844589');
INSERT INTO stock (stock_id, product_id, quantity, created_at, updated_at) VALUES ('aa01bd4a-1bd8-43dd-9c09-1da938a05c59', '45f6ecac-a488-49e3-ac2a-9378cf7235ec', 69, '2025-04-27T11:06:08.973902', '2025-04-27T11:06:08.973902');
INSERT INTO stock (stock_id, product_id, quantity, created_at, updated_at) VALUES ('b235e5a5-380e-40e5-a985-2d5825b59bdb', '5cb03b88-c3e6-44e8-9741-7e5fb7ada20e', 84, '2025-04-27T11:06:09.111232', '2025-04-27T11:06:09.111232');
INSERT INTO stock (stock_id, product_id, quantity, created_at, updated_at) VALUES ('fdb3c713-89cc-44b7-8207-ef3dd43e4e7f', 'e09da891-24dc-401d-977e-c15087a6697b', 51, '2025-04-27T11:06:09.262190', '2025-04-27T11:06:09.262190');

-- Table: stock_movements
DROP TABLE IF EXISTS stock_movements CASCADE;
CREATE TABLE stock_movements (
movement_id character varying NOT NULL,
product_id character varying NOT NULL,
quantity integer NOT NULL,
movement_type character varying NOT NULL,
reason text NULL,
reference_id character varying NULL,
created_at timestamp without time zone NOT NULL
);

-- Data for table: stock_movements
INSERT INTO stock_movements (movement_id, product_id, quantity, movement_type, reason, reference_id, created_at) VALUES ('ccf3724c-84ad-4d2f-be52-5b65a3662ce7', 'f6e181e1-eaab-412f-8341-9457bb2cbc98', 98, 'IN', 'Initial stock', NULL, '2025-04-27T11:06:08.347614');
INSERT INTO stock_movements (movement_id, product_id, quantity, movement_type, reason, reference_id, created_at) VALUES ('9f3fbcd5-ecdd-4275-b622-5f9258dec42c', '492137c0-7ca5-4021-8192-0a4312b01322', 30, 'IN', 'Initial stock', NULL, '2025-04-27T11:06:08.479298');
INSERT INTO stock_movements (movement_id, product_id, quantity, movement_type, reason, reference_id, created_at) VALUES ('291aaed1-6123-45e9-a1c3-7d1483ccce64', '090dd16f-6e37-4334-ae76-b6c35deb963f', 23, 'IN', 'Initial stock', NULL, '2025-04-27T11:06:08.607493');
INSERT INTO stock_movements (movement_id, product_id, quantity, movement_type, reason, reference_id, created_at) VALUES ('54f71c30-6ec4-4695-8b13-dc8e82ec340a', '6af25dab-60cd-4694-ba57-e5a41470c608', 24, 'IN', 'Initial stock', NULL, '2025-04-27T11:06:08.737590');
INSERT INTO stock_movements (movement_id, product_id, quantity, movement_type, reason, reference_id, created_at) VALUES ('255169e2-c473-4021-9577-26ac41a2db7d', '214a5c5c-d345-4a3f-818e-e674d59f773c', 85, 'IN', 'Initial stock', NULL, '2025-04-27T11:06:08.866234');
INSERT INTO stock_movements (movement_id, product_id, quantity, movement_type, reason, reference_id, created_at) VALUES ('c95b9fc4-6c17-4b31-a0ff-7651e09d8e83', '45f6ecac-a488-49e3-ac2a-9378cf7235ec', 69, 'IN', 'Initial stock', NULL, '2025-04-27T11:06:08.997064');
INSERT INTO stock_movements (movement_id, product_id, quantity, movement_type, reason, reference_id, created_at) VALUES ('341fae38-6160-4eea-b91c-eed3a93fc4fb', '5cb03b88-c3e6-44e8-9741-7e5fb7ada20e', 84, 'IN', 'Initial stock', NULL, '2025-04-27T11:06:09.133598');
INSERT INTO stock_movements (movement_id, product_id, quantity, movement_type, reason, reference_id, created_at) VALUES ('9aa27dbe-1b7a-4f43-bb1b-f2b7c2b6fd3c', 'e09da891-24dc-401d-977e-c15087a6697b', 51, 'IN', 'Initial stock', NULL, '2025-04-27T11:06:09.283429');

-- Table: payments
DROP TABLE IF EXISTS payments CASCADE;
CREATE TABLE payments (
payment_id character varying NOT NULL,
invoice_id character varying NOT NULL,
user_id character varying NOT NULL,
amount numeric NOT NULL,
payment_method character varying NOT NULL,
reference_number character varying NULL,
payment_date timestamp without time zone NOT NULL,
notes text NULL,
created_at timestamp without time zone NOT NULL,
updated_at timestamp without time zone NOT NULL
);

-- Table: invoices
DROP TABLE IF EXISTS invoices CASCADE;
CREATE TABLE invoices (
invoice_id character varying NOT NULL,
invoice_number character varying NOT NULL,
user_id character varying NOT NULL,
customer_id character varying NULL,
total_amount numeric NOT NULL DEFAULT 0,
status character varying NOT NULL,
notes text NULL,
created_at timestamp without time zone NOT NULL,
updated_at timestamp without time zone NOT NULL
);

-- Table: customers
DROP TABLE IF EXISTS customers CASCADE;
CREATE TABLE customers (
customer_id character varying NOT NULL,
full_name character varying NOT NULL,
email character varying NULL,
phone character varying NULL,
address text NULL,
tax_id character varying NULL,
notes text NULL,
created_at timestamp without time zone NOT NULL,
updated_at timestamp without time zone NOT NULL
);

-- Data for table: customers
INSERT INTO customers (customer_id, full_name, email, phone, address, tax_id, notes, created_at, updated_at) VALUES ('64216048-cad3-4c55-b429-29e9a5edc3ef', 'John Smith', 'john.smith@example.com', '555-123-4567', '123 Main St, Anytown, USA', NULL, NULL, '2025-04-27T11:04:25.554102', '2025-04-27T11:04:25.554102');
INSERT INTO customers (customer_id, full_name, email, phone, address, tax_id, notes, created_at, updated_at) VALUES ('403aec62-44c8-488d-b57d-2723db5e943b', 'Jane Doe', 'jane.doe@example.com', '555-987-6543', '456 Oak Ave, Somecity, USA', NULL, NULL, '2025-04-27T11:04:25.609793', '2025-04-27T11:04:25.609793');
INSERT INTO customers (customer_id, full_name, email, phone, address, tax_id, notes, created_at, updated_at) VALUES ('c4ac13c4-cb0e-43ce-82ca-325af5ff363d', 'Bob Johnson', 'bob.johnson@example.com', '555-456-7890', '789 Elm St, Anothercity, USA', NULL, NULL, '2025-04-27T11:04:25.653315', '2025-04-27T11:04:25.653315');

-- Table: invoice_items
DROP TABLE IF EXISTS invoice_items CASCADE;
CREATE TABLE invoice_items (
invoice_item_id character varying NOT NULL,
invoice_id character varying NOT NULL,
product_id character varying NOT NULL,
quantity integer NOT NULL,
unit_price numeric NOT NULL,
discount_price numeric NULL,
subtotal numeric NOT NULL,
created_at timestamp without time zone NOT NULL,
updated_at timestamp without time zone NOT NULL
);

-- Table: cash_registers
DROP TABLE IF EXISTS cash_registers CASCADE;
CREATE TABLE cash_registers (
register_id character varying NOT NULL,
user_id character varying NOT NULL,
opening_amount numeric NOT NULL,
current_amount numeric NOT NULL,
closing_amount numeric NULL,
opening_time timestamp without time zone NOT NULL,
closing_time timestamp without time zone NULL,
status character varying NOT NULL,
notes text NULL,
created_at timestamp without time zone NOT NULL,
updated_at timestamp without time zone NOT NULL
);

-- Table: cash_register_transactions
DROP TABLE IF EXISTS cash_register_transactions CASCADE;
CREATE TABLE cash_register_transactions (
transaction_id character varying NOT NULL,
register_id character varying NOT NULL,
user_id character varying NOT NULL,
amount numeric NOT NULL,
transaction_type character varying NOT NULL,
description text NULL,
reference_id character varying NULL,
previous_amount numeric NOT NULL,
new_amount numeric NOT NULL,
created_at timestamp without time zone NOT NULL
);

-- Table: customer_debts
DROP TABLE IF EXISTS customer_debts CASCADE;
CREATE TABLE customer_debts (
debt_id character varying NOT NULL,
customer_id character varying NOT NULL,
invoice_id character varying NOT NULL,
amount numeric NOT NULL,
amount_paid numeric NOT NULL DEFAULT 0,
is_paid boolean NOT NULL DEFAULT false,
created_by character varying NULL,
notes text NULL,
created_at timestamp without time zone NOT NULL,
updated_at timestamp without time zone NOT NULL,
last_payment_date timestamp without time zone NULL
);

-- Table: backups
DROP TABLE IF EXISTS backups CASCADE;
CREATE TABLE backups (
backup_id character varying NOT NULL,
backup_name character varying NOT NULL,
file_path character varying NOT NULL,
file_size bigint NOT NULL,
is_compressed boolean NOT NULL DEFAULT false,
description text NULL,
created_at timestamp without time zone NOT NULL
);

-- Table: restore_logs
DROP TABLE IF EXISTS restore_logs CASCADE;
CREATE TABLE restore_logs (
restore_id character varying NOT NULL,
backup_id character varying NOT NULL,
status character varying NOT NULL,
message text NULL,
created_at timestamp without time zone NOT NULL
);

-- End of backup
